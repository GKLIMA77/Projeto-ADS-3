<!-- ================= header.php ================= -->

<!DOCTYPE html>
<html lang="pt-br">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Barbearia Adrian Souza</title>

<!-- GOOGLE FONTS -->
<link rel="preconnect" href="https://fonts.googleapis.com">

<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<!-- BOOTSTRAP -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- ICONS -->
<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>

<link rel="stylesheet" href="style.css">

</head>

<body>

<!-- ================= NAVBAR ================= -->

<nav class="navbar navbar-expand-lg navbar-dark fixed-top navbar-custom">

<div class="container">

<a class="navbar-brand fw-bold" href="#">
💈 Adrian Souza
</a>

<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">

<span class="navbar-toggler-icon"></span>

</button>

<div class="collapse navbar-collapse" id="menu">

<ul class="navbar-nav ms-auto align-items-lg-center gap-lg-3">

<li class="nav-item">
<a class="nav-link" href="#inicio">Início</a>
</li>

<li class="nav-item">
<a class="nav-link" href="#sobre">Sobre</a>
</li>

<li class="nav-item">
<a class="nav-link" href="#servicos">Serviços</a>
</li>

<li class="nav-item">
<a class="nav-link" href="#galeria">Galeria</a>
</li>

<li class="nav-item">
<a class="nav-link" href="#feedbacks">Feedbacks</a>
</li>

<li class="nav-item">
<a class="nav-link" href="#contato">Contato</a>
</li>

<li class="nav-item">

<a href="#" class="btn btn-warning fw-bold px-4 rounded-pill">
Agendar
</a>

</li>

</ul>

</div>

</div>

</nav>